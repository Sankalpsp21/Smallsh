Compile the program as follows:
    gcc --std=gnu99 -o smallsh smallsh.c

Run the shell with:
    ./smallsh